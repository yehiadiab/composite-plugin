=== WooCommerce Composite Products ===

Contributors: SomewhereWarm
Tags: woocommerce, composite, products, product, kits, builder, configurator, bundle, step, complex, combo, components, combine, personalized, configurable
Requires at least: 6.2
Tested up to: 6.7
Stable tag: 10.2.3
WC requires at least: 8.2
WC tested up to: 9.2
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Create personalized product kits and configurable products.

== Description ==

With support for simple and variable products, downloadable products and product bundles, Composite Products is a powerful kit builder that works in a wide range of scenarios.

Looking for help? Read the full plugin documentation [here](http://woocommerce.com/document/composite-products/).
